    class Task {name;id;due;containerid;checked;children;
        constructor(name,id, due, containerid, checked, children) {
            this.name = name;
            this.id = id;
            this.due = due;
            this.containerid = containerid;
            this.checked = checked;
            this.children = children;
        }
    }

    window.onload = async function () {
        const dbName = 'Todo';
        const isExisting = (await window.indexedDB.databases()).map(db => db.name).includes(dbName);
        let modalSubTask = document.getElementById("modalSub");
        let modalEditTask = document.getElementById("modalEdit");
        modalSubTask.style.display = "none";
        modalEditTask.style.display = "none";

        var indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB || window.shimIndexedDB;
        if (!window.indexedDB) {
            console.log("Your browser doesn't support a stable version of IndexedDB.");
        }

    const DB = new Promise((resolve, reject) => {
        const request = window.indexedDB.open('Todo', 1);
        request.onupgradeneeded = function (event) {
            request.result.createObjectStore("tasklist", { keypath: 'id' });
            request.result.createObjectStore("taskcontainerslist", { autoIncrement: true });
            request.result.createObjectStore("subtaskslist", { keypath: 'id3' });
        }

        request.onsuccess = () => resolve(request.result);
        request.onerror = e => reject(e);
    })


    let tasksMain = [];
    let filterroot = false;

    const renderTasks = (tasksfiltered, filter) => {
        DB.then(db => {
            const request = db.transaction('tasklist', 'readwrite').objectStore('tasklist').getAll();
            const request2 = db.transaction('taskcontainerslist', 'readwrite').objectStore('taskcontainerslist').getAll();
            request2.onsuccess = e => {
                containerMain = e.target.result;
                console.log('containerMain: ', containerMain);

                const listTodo = document.getElementById('list__todo');
                listTodo.innerHTML = "";
                let containersHolder;
                if (filter === false) {
                    containersHolder = containerMain[0].containers;
                    console.log('containersHolder: ', containersHolder, "false filter called");

                }
                else {
                    containersHolder = tasksfiltered;
                    console.log('containersHolder: ', containersHolder, "true filter called");
                }
                console.log('containersHolder: ', containersHolder);
                containersHolder.forEach((container) => {
                    let child1;
                    let child2;
                    let child3;
                    let containerChildren = container.task.children;
                    if (containerChildren[0]) {
                        child1 = containerChildren[0];
                    }
                    else {
                        child1 = '';
                    }
                    if (containerChildren[1]) {
                        child2 = containerChildren[1];
                    }
                    else {
                        child2 = '';
                    }
                    if (containerChildren[2]) {
                        child3 = containerChildren[2];
                    }
                    else {
                        child3 = '';
                    }
                
                    const taskEl = document.createElement('li');
                    taskEl.className = 'height--onethird';
                    taskEl.innerHTML = `
                                 <div id=${container.id2} class="dropzone border--solid overflow">
                                 <div data-id=${container.task.id} id=${container.task.id} " class="container__todo">
                                 <div class="container--row">
                                 <span>Title: ${container.task.name}<span>
                                 <span style="margin-left: 1vw;">Date: ${container.task.due}</span>
                                 </div>
                                 <p>${child1}</p>
                                 <p>${child2}</p>
                                 <p>${child3}</p>
                                 </div>
                                 </div>
                            `;

                    // Buttons Container
                    const ulBtns = document.createElement('ul');
                    ulBtns.className = 'container--row';
                    ulBtns.innerHTML = '<li></li>';

                    const addSub = document.createElement('li');
                    addSub.className = 'btn--sub';
                    addSub.innerHTML = '<span class="border--solid" style="margin-left: 1vw;">Add SubTask</span>';

                    addSub.addEventListener('click', (event) => {
                        if (filter) {
                            alert("sorry you are in filtered mode, click reset to enable");
                        }
                        else {
                            modalSubTask.style.display = "block";
                            modalSubTask.style.position = "fixed";
                            modalSubTask.style.top = "10vh";
                            modalSubTask.style.left = "40vw";
                            modalSubTask.style.background = "rgb(0, 0, 0)";
                            console.log('subId: ', container.id2);

                            let add = document.getElementById('btn__addSubTask--modal');
                            add.addEventListener('click', () => {
                                let containerChildren = container.task.children;
                                let subinput = document.getElementById('subtask--name').value;
                                containerChildren.push(subinput);
                                container.task.children = containerChildren;
                                const subrequest = db.transaction('taskcontainerslist', 'readwrite').objectStore('taskcontainerslist').put({ containers: containersHolder }, 0);
                                subrequest.onsuccess = e => {
                                    console.log("put", subinput, "in", container.task.name);
                                }
                                renderTasks('', false);
                            });
                        }
                    });

                    const editBtn = document.createElement('li');
                    editBtn.className = 'btn';
                    editBtn.innerHTML = '<span class="border--solid" style="margin-left: 1vw;">Edit Task</span>';

                    editBtn.addEventListener('click', (event) => {
                        if (filter) {
                            alert("sorry you are in filtered mode, click reset to enable");
                        }
                        else {
                            modalEditTask.style.display = "block";
                            modalEditTask.style.position = "fixed";
                            modalEditTask.style.top = "10vh";
                            modalEditTask.style.left = "40vw";
                            modalEditTask.style.background = "rgb(10, 10, 0)";
                            console.log('subId: ', container.id2);
                            let edit = document.getElementById('btn--EditModal');
                            edit.addEventListener('click', () => {
                                let editTitle = document.getElementById("edittask--name").value;
                                let editdue = document.getElementById("task__edit--due").value;
                                container.task.name = editTitle;
                                container.task.due = editdue;
                                const editrequest = db.transaction('taskcontainerslist', 'readwrite').objectStore('taskcontainerslist').put({ containers: containersHolder }, 0);
                                editrequest.onsuccess = e => {
                                    console.log("edited", container.task.name);
                                }
                                renderTasks('', false);
                            });
                        }
                    });

                    const delBtn = document.createElement('li');
                    delBtn.className = 'btn';
                    delBtn.innerHTML = '<span class="border--solid" style="margin-left: 1vw;">Delete Task</span>';
                    delBtn.addEventListener('click', (event) => {
                        if (filter) {
                            alert("sorry you are click reset to enable");
                        }
                        else {
                            let tempContainers = containersHolder;
                            let atIndex = tempContainers.findIndex(el => el.id == container.id);
                            tempContainers.splice(atIndex, 1);
                            containersHolder = tempContainers;
                            const delrequest = db.transaction('taskcontainerslist', 'readwrite').objectStore('taskcontainerslist').put({ containers: containersHolder }, 0);
                            delrequest.onsuccess = e => {
                                console.log("deleted");
                            }
                            renderTasks('', false);
                        }
                    });

                    const markBtn = document.createElement('li');

                    ulBtns.append(addSub);
                    ulBtns.append(editBtn);
                    ulBtns.append(delBtn);
                    ulBtns.append(markBtn);

                    const listTodo = document.getElementById('list__todo');
                    listTodo.appendChild(taskEl);
                    listTodo.appendChild(ulBtns);
                });
            };
        });
    };

   
    if (isExisting) {
        renderTasks('', false);
    }
    //function to add tasks to database
    const addTasks = () => {
        let name = document.getElementById("task--name").value;
        let due = document.getElementById("task--due").value;
        let id = Math.random();
        let id2 = Math.random();
        let ind = 0;
        const fal = false;
        const emp = [];
        let autoInc;
        DB.then(db => {
            const request = db.transaction('tasklist', 'readwrite').objectStore('tasklist').getAll();
            request.onsuccess = e => {
                let taskTemp = new Task(`${name}`, `${id}`, `${due}`, `${id2}`);
                const store = db.transaction('tasklist', 'readwrite').objectStore('tasklist');
                store.add(taskTemp, id);
            }

            const request2 = db.transaction('taskcontainerslist', 'readwrite').objectStore('taskcontainerslist').getAll();
            request2.onsuccess = e => {
                const store2 = db.transaction('taskcontainerslist', 'readwrite').objectStore('taskcontainerslist');
                let taskTemp = new Task(`${name}`, `${id}`, `${due}`, `${id2}`, false, []);
                let rootTemp = request2.result;
                if (rootTemp.length === 0) {
                    let containerTemp = { id2: id2, task: taskTemp };
                    let tempContainers = [];
                    tempContainers.push(containerTemp);
                    store2.add({ containers: tempContainers }, 0);
                }
                else {
                    let containerTemp = { id2: id2, task: taskTemp };
                    let tempContainers = rootTemp[0].containers;
                    tempContainers.push(containerTemp);
                    store2.put({ containers: tempContainers }, 0);
                }
            };
        });
    };

    const search = document.getElementById('btnsearch');
    const reset = document.getElementById('reset');
    const  today =document.getElementById('today');

    searchTasks = () => {
        DB.then(db => {
            const request2 = db.transaction('taskcontainerslist', 'readwrite').objectStore('taskcontainerslist').getAll();
            request2.onsuccess = e => {
                let tempContainerMain = request2.result;
                let tempContainerHolder = tempContainerMain[0].containers;
                const searchinput = document.getElementById('search--task').value;
                function filterBySearch(item, index) {
                    let namevar = item.task.name;
                    console.log('namevar: ', namevar);
                    let bool = namevar.includes(searchinput);
                    if (bool) {
                        return true
                    }
                    return false;
                }
                let searchTrimmed = tempContainerHolder.filter(filterBySearch);
                renderTasks(searchTrimmed, true);
            };
        });
    };

    resetTasks = () => {
        renderTasks('', false);
        filterroot = false;
    };

    todayTask =() =>{
       
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();
        today = yyyy + '/' + mm + '/' + dd;
        document.write(today);

    }

    filterTasks = () => {
        DB.then(db => {
            const request2 = db.transaction('taskcontainerslist', 'readwrite').objectStore('taskcontainerslist').getAll();
            request2.onsuccess = e => {
                let tempContainerMain = request2.result;
                let tempContainerHolder = tempContainerMain[0].containers;
            };
        });
    };
   
    search.addEventListener('click', searchTasks);
    reset.addEventListener('click', resetTasks);
    today.addEventListener('click',todayTask);

    //----------------------Modal Script---------------------- 
    var modal = document.getElementById("myModal");
    var btn = document.getElementById("btn__addTask");
    var btnModal = document.getElementById("btn__addTask--modal");
    var btncloseModal = document.getElementById("btn--closeModal");

    btn.onclick = function () {
        modal.style.display = "block";
    }

    btnModal.onclick = function () {
        modal.style.display = "none";
    }

    btnModal.addEventListener('click', () => {
        renderTasks('', false);
        addTasks();
    });

    btncloseModal.onclick = function () {
        modal.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    var btnSubModal = document.getElementById("btn__addSubTask--modal");
    var btncloseSubModal = document.getElementById("btn--closeSubModal");
    btnSubModal.onclick = function () {
        modalSubTask.style.display = "none";
    }

    btnSubModal.addEventListener('click', () => {
        renderTasks('', false);
        addTasks();
    });

    btncloseSubModal.onclick = function () {
        modalSubTask.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == modal) {
            modalSubTask.style.display = "none";
        }
    }

    var btnEditModal = document.getElementById("btn--EditModal");
    var btncloseEditModal = document.getElementById("btn--closeEditModal");
    btnEditModal.onclick = function () {
        modalEditTask.style.display = "none";
    }

    btnEditModal.addEventListener('click', () => {
        renderTasks('', false);
        addTasks();
    });

    btncloseEditModal.onclick = function () {
        modalEditTask.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target == modal) {
            modalEditTask.style.display = "none";
        }
    }
};




